#include "stm32f10x.h"                  // Device header
#include "Motor.h"
#include "Delay.h"
#include "Car.h"
#define LineL1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10)
#define LineL2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)
#define LineR1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_12)
#define LineR2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)

#define LOW 1
#define HIGH 0

void Xunji_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void Xunji_Start(void)
{
		if( (LineL1 == LOW || LineL2 == LOW) && LineR2 == LOW) //�����
    {
//      	// Self_Left();
//		Delay_ms(80);
    }
    else if ( LineL1 == LOW && (LineR1 == LOW || LineR2 == LOW)) //�Ҵ���
	{ 
//      	Self_Right();
//		Delay_ms(80);
    }  
    else if( LineL1 == LOW ) //���������
    {  
//		Self_Left();
//		Delay_ms(10);
	}
    else if ( LineR2 == LOW) //���������
    {  
//			Self_Right();
//		Delay_ms(10);
	}
    else if (LineL2 == LOW && LineR1 == HIGH) //�м�����ϵĴ�����΢������ת
    {   
//		Self_Left();   
	}
	else if (LineL2 == HIGH && LineR1 == LOW) //�м�����ϵĴ�����΢������ת
    {   
//		Self_Right();   
	}
    else if(LineL2 == LOW && LineR1 == LOW) // ���Ǻ�ɫ, ����ǰ��
    {  
//		 Go_Ahead();
	}	
}
