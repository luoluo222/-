#include "stm32f10x.h"                  // Device header
#include "motorcan.h"
#include "ENCODER.H"

extern MOTOR_CAN motor1_state;
extern MOTOR_CAN motor2_state;
int16_t Encoder_MOTOR1;
int16_t Encoder_MOTOR2;
#define length 24.0f		//cm


void Motor_ecd_init(MOTOR_CAN* ptr)
{
	if(ptr == &motor1_state)
		ptr->now_ecd = Encoder1_get();
	else
		ptr->now_ecd = Encoder2_get();
	
	ptr->last_ecd = ptr->now_ecd;
}

void GET_MOTOR_CAN(MOTOR_CAN *ptr,int32_t tarspeed)
{ 
	if(ptr == &motor1_state)
		ptr->now_ecd = Encoder1_get();
	else
		ptr->now_ecd = Encoder2_get();
	
	ptr ->now_speed = (float)(ptr->now_ecd - ptr->last_ecd) / 4.0f / 11.0f / 56.0f * length * 3.14f * 5;
	ptr->last_ecd = ptr->now_ecd;
	
	ptr ->now_position += ptr ->now_speed;	
    ptr ->tar_position=ptr->tar_position;	
   
	ptr ->tar_speed=tarspeed;	   	
}


