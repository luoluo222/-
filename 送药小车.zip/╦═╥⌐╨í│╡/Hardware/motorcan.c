#include "stm32f10x.h"                  // Device header
#include "motorcan.h"
#include "ENCODER.H"

int16_t Encoder_MOTOR1;
int16_t Encoder_MOTOR2;
#define length 0.24
//#define tarspeed 20
//#define tarposition 2000
double speed_Get1(void)
{
	double speed;
	Encoder_MOTOR1 = Encoder1_get();
	speed=(float)Encoder_MOTOR1;///4.0/11.0/(56.0);
	return speed;
	
}
double speed_Get2(void)
{
	double speed;
	Encoder_MOTOR2 = Encoder2_get();
	speed=(float)Encoder_MOTOR2;///4.0/11.0/56.0;
	return speed;
}


void GET_MOTOR1_CAN(MOTOR1_CAN *ptr,int16_t tarspeed,int16_t tarposition)
{ 
	
	ptr ->now_speed=  speed_Get1();
    ptr ->now_position += speed_Get1();	
    ptr ->tar_speed=tarspeed;	   	
    ptr ->tar_position=tarposition;	
}



void GET_MOTOR2_CAN(MOTOR2_CAN *ptr,int16_t tarspeed,int16_t tarposition)
{
	
	ptr ->now_speed= speed_Get2();
    ptr ->now_position += speed_Get2();	
    ptr ->tar_speed=tarspeed;	   	
    ptr ->tar_position=tarposition;	
}

