#ifndef __MOTORCAN_H
#define __MOTORCAN_H
#include "stm32f10x.h"                  // Device header

typedef struct{
	double	 	now_speed;   		
    double  	now_position;		
    int16_t  	tar_speed;	   	
    uint32_t  	tar_position;
	uint32_t    all_distance;
	int16_t		total_angle;
	int16_t		now_angle;
	int16_t		tar_angle;
	
}MOTOR1_CAN;  
typedef struct{
	double	 	now_speed;   		
    double  	now_position;		
    int16_t  	tar_speed;	   	
    uint32_t  	tar_position;
	uint32_t    all_distance;
	int16_t		total_angle;
	int16_t		now_angle;
	int16_t		tar_angle;
	
}MOTOR2_CAN; 
extern  int16_t Encoder1_get(void);
extern  int16_t Encoder2_get(void);
void GET_MOTOR1_CAN(MOTOR1_CAN *ptr,int16_t tarspeed,int16_t tarposition);
void GET_MOTOR2_CAN(MOTOR2_CAN *ptr,int16_t tarspeed,int16_t tarposition);
double speed_Get1(void);
double speed_Get2(void);
#endif
