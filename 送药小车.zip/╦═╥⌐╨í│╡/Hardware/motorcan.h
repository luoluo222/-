#ifndef __MOTORCAN_H
#define __MOTORCAN_H
#include "stm32f10x.h"                  // Device header

typedef struct{
	int32_t		now_ecd;
	int32_t		last_ecd;
	float	 	now_speed;   		
    float  		now_position;		
    float 		tar_speed;	   	
    float  		tar_position;
	int32_t   	all_distance;
	uint32_t	motor_cnt;
}MOTOR_CAN;  


extern  int16_t Encoder1_get(void);
extern  int16_t Encoder2_get(void);
void GET_MOTOR_CAN(MOTOR_CAN *ptr,int32_t tarspeed);
void Motor_ecd_init(MOTOR_CAN* ptr);

#endif
