#include "stm32f10x.h"                  // Device header
#include "pwm.h"

#define Speed_to_Pwm_Rate	0.333f		//x(cm/s) <-> x(pwm) x * 99 / 300 

void Motor_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	PWM_Init();
}

void Motor_SetLeftSpeed(float Speed1)
{
	if (Speed1 >0)
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_0);
		PWM_SetCompare1(Speed1 * Speed_to_Pwm_Rate);
	}
	else if(Speed1==0){
		GPIO_SetBits(GPIOB, GPIO_Pin_0);
		GPIO_SetBits(GPIOB, GPIO_Pin_1);
		PWM_SetCompare1(Speed1);
	}else{
		GPIO_ResetBits(GPIOB, GPIO_Pin_1);
		GPIO_SetBits(GPIOB, GPIO_Pin_0);
		PWM_SetCompare1(-Speed1 * Speed_to_Pwm_Rate);
	}
}
void Motor_SetRightSpeed(float Speed2)
{
	if (Speed2 >0)
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_14);
		GPIO_ResetBits(GPIOB, GPIO_Pin_15);
		PWM_SetCompare2(Speed2 * Speed_to_Pwm_Rate);
	}
	else if(Speed2==0){
		GPIO_SetBits(GPIOB, GPIO_Pin_14);
		GPIO_SetBits(GPIOB, GPIO_Pin_15);
		PWM_SetCompare2(Speed2);
	}else{
		GPIO_ResetBits(GPIOB, GPIO_Pin_14);
		GPIO_SetBits(GPIOB, GPIO_Pin_15);
		PWM_SetCompare2(-Speed2 * Speed_to_Pwm_Rate);
	}
}
