#ifndef __MOTOR_H
#define __MOTOR_H
void Motor_Init(void);
void Motor_SetLeftSpeed(int16_t Speed1);
void Motor_SetRightSpeed(int16_t Speed2);



#endif
