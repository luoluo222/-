#ifndef __INFRARED_H
#define __INFRARED_H
void Infrared_Init();
#endif