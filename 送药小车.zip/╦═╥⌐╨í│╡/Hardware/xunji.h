#ifndef __XUNJI_H
#define __XUNJI_H

#define LineL1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)
#define LineL2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)
#define LineR1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)
#define LineR2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)
#define LOW 0
#define HIGH 1

void Xunji_Init(void);
void Xunji_Start(void);

#endif