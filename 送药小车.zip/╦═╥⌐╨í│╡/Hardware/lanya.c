#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>

void Usart_Init(void){
  
    GPIO_InitTypeDef GPIO_InitStructure;   //GPIO�˿�����
	USART_InitTypeDef USART_InitStructure;  //USART����
	NVIC_InitTypeDef NVIC_InitStructure;  //�ж�����
	 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);	//ʹ��USART1��GPIOAʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; //PB10
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//����������� Tx
    GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOB10
   
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;//PB11
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//�������� Rx
    GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOB11 

	//USART ��ʼ������
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	
    //Usart1 NVIC ����
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	
	
	USART_Init(USART3, &USART_InitStructure); //��ʼ������3
	
	USART_Cmd(USART3, ENABLE); //ʹ�ܴ���3
	
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);//�������ڽ����ж�

}

void USART_SendString(USART_TypeDef* USARTx,char *DataString)
{
	USART_ClearFlag(USARTx,USART_FLAG_TC);
	int i=0;
	while(DataString[i]!='\0')
	{
		USART_SendData(USARTx,DataString[i]);
		while(USART_GetFlagStatus(USARTx,USART_FLAG_TC)==0);
		USART_ClearFlag(USARTx,USART_FLAG_TC);
		i++;
	}
}
