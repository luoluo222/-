#ifndef __LANYA_H
#define __LANYA_H
#include "stm32f10x.h"                  // Device header

void Usart_Init(void);
void USART_SendString(USART_TypeDef* USARTx,char *DataString);

#endif
