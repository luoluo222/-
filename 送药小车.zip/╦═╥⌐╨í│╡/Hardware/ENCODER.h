#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_Init(void);
extern int16_t Encoder1_get(void);
void TIM3_IRQHandler(void);

void Encoder2_Init(void);
extern int16_t Encoder2_get(void);
void TIM4_IRQHandler(void);

#endif
