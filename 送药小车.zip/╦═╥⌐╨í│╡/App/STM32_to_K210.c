#include <STM32_to_K210.h>
#include <Data_typedef.h>
#include <Serial.h>
#include <upacker.h>
#include <ringbuffer.h>
#include "Sys_Time_IRQHandle.h"


#define DEBUG_PROTOCOL_K210_data 1

//ͨ��״̬��
typedef enum
{
   APP_PROTOCOL_INIT = 0,
   APP_PROTOCOL_RUN,
   APP_PROTOCOL_STOP
} app_protocol_status_t;

static app_protocol_status_t app_protocol_status = APP_PROTOCOL_INIT;

//uint8_t RxStatus = 0;  //��־λ
//extern uint32_t RxBuffer[20];
//extern uint8_t USART2_ReceSize;
//extern uint16_t RxCounter;

static upacker_inst k210_msg_packer;
k210_data_t Rx_K210_Data;

// ��һ�ν��յ�K210���������ݵ�ʱ��
static uint32_t last_receive_k210_tick = 0;

// ringbuffer������

static ring_buffer_t rb_uart2;
static uint8_t uart2_rb_buff[UART2_RING_BUFFER_LEN];
//

//����������

uint8_t uart2_recv_buff[UART2_RECEIVE_LENGTH];
//

void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);		//���ֽ�����д�����ݼĴ�����д���USART�Զ�����ʱ����
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//�ȴ��������
	/*�´�д�����ݼĴ������Զ����������ɱ�־λ���ʴ�ѭ�������������־λ*/
}

int fputc(int ch, FILE *f)
{
	Serial_SendByte(ch);			//��printf�ĵײ��ض����Լ��ķ����ֽں���
	return ch;
}

/**
 * @brief  k210���ͽӿ�
 * @note
 * @param  *buff:
 * @param  len:
 * @retval None
 */
static void k210_protocol_send(uint8_t *buff, uint16_t len)
{
    for(uint16_t i = 0; i < len; i++)
    {
        Serial_SendByte(buff[i]);		//����ÿ���ֽ�����
    }
}

uint32_t receive_count = 0;
/**
 * @brief  k210��Ϣ�����ص�
 * @note
 * @param  *buff:
 * @param  size:
 * @retval None
 */
static void k210_protocol_handle_cb(uint8_t *buff, uint16_t len)
{
    static uint32_t temp_tick;
    // ���յ�payload,����������������ݾ����Ѿ�У�������
    receive_count++;
    if (get_system_tick() - temp_tick >= 1000)
    {
		// printf("rec:%d\n",receive_count);
        receive_count = 0;
        temp_tick = get_system_tick();
    }

    last_receive_k210_tick = get_system_tick();

    Rx_K210_Data.work_mode = buff[0];
    Rx_K210_Data.recognition = buff[1];
    Rx_K210_Data.top_block_offset = buff[2] + (buff[3] << 8);
    Rx_K210_Data.center_block_offset = buff[4] + (buff[5] << 8);
    Rx_K210_Data.left_block_offset = buff[6] + (buff[7] << 8);
    Rx_K210_Data.right_block_offset = buff[8] + (buff[9] << 8);
    Rx_K210_Data.left_number = buff[10];
    Rx_K210_Data.right_number = buff[11];


#if DEBUG_PROTOCOL_K210_data == 1
    printf("mode,reco,top,center,left,right,left_num,right_num:%d,%d,%d,%d,%d,%"
           "d,%d,%d\n",
           Rx_K210_Data.work_mode, Rx_K210_Data.recognition,
           Rx_K210_Data.top_block_offset, Rx_K210_Data.center_block_offset,
           Rx_K210_Data.left_block_offset, Rx_K210_Data.right_block_offset,
           Rx_K210_Data.left_number, Rx_K210_Data.right_number);
#endif

}

uint8_t get_start_number(void)
{
    static k210_data_t *_k210_data;

    _k210_data = get_k210_data();
    if (_k210_data->left_number == _k210_data->right_number)
    {
        return _k210_data->left_number;
    }
    else
    {
        return 0;
    }
}

//K210 �����ݲ������ж���ı�ģ����Բ����ٽ�������
k210_data_t * get_k210_data(void)
{
    return &Rx_K210_Data;
}

int send_uart_k210_to_find_lines(void)
{
    static uint8_t temp = 0x00;
    upacker_pack(&k210_msg_packer, &temp, 1);
    return 0;
}
int send_uart_k210_to_find_number(void)
{
    static uint8_t temp = 0x01;
    upacker_pack(&k210_msg_packer, &temp, 1);
    return 0;
}

static uint8_t receive_char;

void app_protocol_run(void)
{
    switch (app_protocol_status)
    {
    case APP_PROTOCOL_INIT:

        ring_buffer_init(&rb_uart2, uart2_rb_buff, UART2_RING_BUFFER_LEN);
//        ring_buffer_init(&rb_uart5, uart5_rb_buff, UART5_RING_BUFFER_LEN);

        // init k210 packer
        upacker_init(&k210_msg_packer, k210_protocol_handle_cb,
                     k210_protocol_send);
        // init ble packer
//        upacker_init(&ble_msg_packer, ble_protocol_handle_cb,
//                     ble_protocol_send);

        app_protocol_status++;
        break;
    case APP_PROTOCOL_RUN:

        if (ring_buffer_available_read(&rb_uart2) >= 1)
        {
            ring_buffer_read(&rb_uart2, &receive_char, 1);

            upacker_unpack(&k210_msg_packer, &receive_char, 1);
        }
//        if (ring_buffer_available_read(&rb_uart5) >= 1)
//        {
//            ring_buffer_read(&rb_uart5, &receive_char, 1);

//            upacker_unpack(&ble_msg_packer, &receive_char, 1);
//        }

//        update_ble_online_flag();

//        update_k210_online_flag();

        break;
    case APP_PROTOCOL_STOP:

        break;
    default:
        break;
    }
}

void USART1_IRQHandler(void)
{
    if(USART_GetITStatus(USART1, USART_IT_IDLE) != RESET)
    {

		DMA_Cmd(DMA1_Channel5, DISABLE);                // ֹͣDMA�����DMA����

		USART_ReceiveData(USART1);

		ring_buffer_write(&rb_uart2, (uint8_t *)&uart2_recv_buff,
                          UART2_RECEIVE_LENGTH);
		

		
        USART_ClearITPendingBit(USART1, USART_IT_IDLE); // ��������ж�

        
		DMA_SetCurrDataCounter(DMA1_Channel5, UART2_RECEIVE_LENGTH);
        DMA_Cmd(DMA1_Channel5, ENABLE);     
    }

}
