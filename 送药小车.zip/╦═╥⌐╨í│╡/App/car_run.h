#ifndef __car_run_H
#define __car_run_H

#include "stm32f10x.h"                  // Device header

void app_car_control_run(void);

#endif
