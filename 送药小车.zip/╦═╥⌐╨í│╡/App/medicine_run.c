#include "medicine_run.h"

int get_medicine_state(void)
{
	return 1;
}