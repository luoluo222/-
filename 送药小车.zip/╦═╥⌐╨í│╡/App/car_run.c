#include "car_run.h"
#include <Data_typedef.h>
#include <STM32_to_K210.h>
#include "Sys_Time_IRQHandle.h"
#include "medicine_run.h"
#include "motorcan.h"
#include "pid_run.h"

// ����λ����Ϣ����������ʾ�������ʵ�ʵ�ͼ����
/*    	   
		f			  g
		|			  |
		4------3------5
		|	   |	  |
	    e   c--2--d   h
			   |
			a--1--b
			   |
			   0
*/

#define CAR_DEFAULT_SPEED 3.0f
#define CAR_CONTROL_SPIN_LEFT_NUM   -608
#define CAR_CONTROL_SPIN_RIGHT_NUM  608
#define CAR_CONTROL_SPIN_RETURN_NUM -1200
#define ABS(x)		((x>0)? (x): (-x))

//static uint8_t a_temp_step = 0;
//static uint8_t b_temp_step = 0;
//static uint8_t c_temp_step = 0;
//static uint8_t d_temp_step = 0;

static uint8_t third_temp_step = 0;
static uint8_t fourth_temp_step = 0;

//static uint8_t e_temp_step = 0;
//static uint8_t f_temp_step = 0;
//static uint8_t g_temp_step = 0;
//static uint8_t h_temp_step = 0;
static uint8_t temp_step = 0;
static uint16_t step_situation=0;


extern MOTOR_CAN motor1_state;
extern MOTOR_CAN motor2_state;

typedef enum
{
    APP_CAR_CONTROL_INIT = 0,
    APP_CAR_CONTROL_WAIT_FOR_K210_NUMBER,
    APP_CAR_CONTROL_WAIT_FOR_LOAD,
    APP_CAR_CONTROL_FIRST_JUDGE,
    APP_CAR_CONTROL_GOTO_A,
    APP_CAR_CONTROL_GOTO_B,
    APP_CAR_CONTROL_SECOND_JUDGE,
    APP_CAR_CONTROL_2_GOTO_C,
    APP_CAR_CONTROL_2_GOTO_D,
    APP_CAR_CONTROL_THIRD_JUDGE,
    APP_CAR_CONTROL_FOURTH_JUDGE,
    APP_CAR_CONTROL_4_GOTO_E,
    APP_CAR_CONTROL_4_GOTO_F,
    APP_CAR_CONTROL_5_GOTO_G,
    APP_CAR_CONTROL_5_GOTO_H,

    APP_CAR_CONTROL_STOP,
} app_car_control_status_t;

static app_car_control_status_t app_car_control_status = APP_CAR_CONTROL_INIT;//С������˳��

static medical_ward_info_t medical_ward_info;//С��������Ϣ

// С��λ����Ϣ,���յ�24�е�ͼ����
// ��ѡ��a,b,c,d,e,f,g,h,0,1,2,3,4,5
static char car_position = 0;




int car_go_until_sickroom(float _speed, int32_t _encoder_count,
                          int32_t _position_target)
{
    enum _state_t
    {
        _START = 0,
        _WAIT_DECELERATE,
        _DECELERATE,
        _POSITION_RUN,
        _STOP
    };
    static enum _state_t state = _START;

    static int32_t temp_start_distance = 0;
    static uint32_t temp_systick;
    static k210_data_t *_k210_data;

    _k210_data = get_k210_data();

    switch (state)
    {
    case _START:
        deactive_car_position_pid();
        active_car_red_lines_pid();

        set_car_red_lines_speed(_speed);
        temp_start_distance = motor1_state.now_position;//!!!!!!!!!!!!!!!!!!!!!

        state++;
        break;
    case _WAIT_DECELERATE:
        if (motor1_state.now_position - temp_start_distance >= _encoder_count)//!!!!
        {
            state++;
        }
        break;
    case _DECELERATE:
        set_car_red_lines_speed(1.5f);
        if (_k210_data->recognition == 0x01)
        {
            state++;
            set_car_red_lines_speed(0.0f);
            active_car_position_pid();
            deactive_car_red_lines_pid();
			
			//ǰ��
            tar(&motor1_state,_position_target);//
			tar(&motor2_state,_position_target);//
			
            temp_systick = get_system_tick();
        }
        break;
    case _POSITION_RUN:
        if (get_system_tick() - temp_systick >= 300)
        {
            state++;
        }
        else if (_position_target == 0)
        {
            state++;
        }
        break;
    case _STOP:
        set_car_red_lines_speed(0.0f);
        deactive_car_position_pid();
        deactive_car_red_lines_pid();
        state = _START;
        return 1;
    }
    return 0;
}

int car_go_until_crossing(float _speed,int32_t _encoder_count,int32_t _position_target)
{
    enum _state_t
    {
        _START = 0,
        _WAIT_DECELERATE,
        _DECELERATE,
        _POSITION_RUN,
        _STOP
    };
    static enum _state_t state = _START;

    static int32_t temp_start_distance = 0;
    static k210_data_t *_k210_data;

    _k210_data = get_k210_data();

    switch (state)
    {
    case _START:
        deactive_car_position_pid();
        active_car_red_lines_pid();

        set_car_red_lines_speed(_speed);
        temp_start_distance = motor1_state.now_position;
        state++;
        break;
    case _WAIT_DECELERATE:
        if(ABS(motor1_state.now_position - temp_start_distance) >= _encoder_count)
        {
            set_car_red_lines_speed(0.0f);
            state++;
        }
        break;
    case _DECELERATE:
        set_car_red_lines_speed(1.5f);
        if (_k210_data->recognition == 0x02)
        {
            state++;
            set_car_red_lines_speed(0.0f);
            active_car_position_pid();
            deactive_car_red_lines_pid();
            //ǰ��
			tar(&motor1_state,_position_target);//
			tar(&motor2_state,_position_target);//
			
        }
        break;
    case _POSITION_RUN:
        if (ABS(motor1_state.tar_position - motor1_state.now_position) <= 50)
        {
//            printf("m1_position_target,m1_position_measurement:%d,%d\n",(int32_t)get_m1_position_target(),get_m1_position_measurement());
            state++;
        }
        break;
    case _STOP:
        set_car_red_lines_speed(0.0f);
        deactive_car_position_pid();
        active_car_red_lines_pid();
        state = _START;
        return 1;
    }
    return 0;
}

// ��ǰλ����ת
static int car_spin(int32_t _count,float _speed,uint32_t _wait_pos_tick,uint32_t _wait_line_tick)
{
    static uint32_t temp_systick;

    enum _state_t
    {
        _START = 0,
        _WAIT_COMPLETE,
        _START_FINE_LINE,
        _STOP
    };

    static enum _state_t state = _START;

    switch (state)
    {
    case _START:
        deactive_car_red_lines_pid();
        active_car_position_pid();

        //λ����ת
		

        temp_systick = get_system_tick();

        state++;
        break;
    case _WAIT_COMPLETE:
        if (get_system_tick() - temp_systick >= _wait_pos_tick)
        {
            deactive_car_position_pid();
            active_car_red_lines_pid();
            temp_systick = get_system_tick();
            state++;
        }
        break;
    case _START_FINE_LINE:
        if (get_system_tick() - temp_systick >= _wait_line_tick)
        {
            state++;
        }
        break;
    case _STOP:
        set_car_red_lines_speed(0.0f);
        state = _START;
        return 1;
    }
    return 0;
}

void car_run_ABCD(uint16_t situation)
{
	temp_step = 0;
	if(situation==3||situation==4)temp_step=1;
	switch (temp_step)
        {
        case 0:
            if (car_go_until_crossing(CAR_DEFAULT_SPEED, 3000, 1000))
            {
                car_position = '1';
                temp_step++;
            }
            break;
        case 1:
			if(situation==1||situation==3)
			{
				if (car_spin(CAR_CONTROL_SPIN_LEFT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
			else 
			{
				if (car_spin(CAR_CONTROL_SPIN_RIGHT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
            
            break;
        case 2:
            if (car_go_until_sickroom(CAR_DEFAULT_SPEED, 1500, 200))
            {
                // ���ﲡ����
				switch(situation)
				{
					case 1:car_position = 'a';break;
					case 2:car_position = 'b';break;
					case 3:car_position = 'c';break;
					case 4:car_position = 'd';break;
				}
                
                //bsp_led_on(LED_RED);
                temp_step++;
            }
            break;
        case 3:
            if (get_medicine_state() == (uint8_t)0)
            {
                //bsp_led_off(LED_RED);
                //buzzer_beep_tone(4000, 100, 100, 100);
                temp_step++;
            }
            break;
        case 4:
            if (car_spin(CAR_CONTROL_SPIN_RETURN_NUM, CAR_DEFAULT_SPEED, 500,
                         300))
            {
                temp_step++;
            }
            break;
        case 5:
            if (car_go_until_crossing(CAR_DEFAULT_SPEED, 300, 1200))
            {
                car_position = '1';
                temp_step++;
            }
            break;
        case 6:
			if(situation==1||situation==3)
			{
				if (car_spin(CAR_CONTROL_SPIN_RIGHT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
			else 
			{
				if (car_spin(CAR_CONTROL_SPIN_LEFT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
            break;
        case 7:
			if(situation<=2)
			{
				if (car_go_until_sickroom(CAR_DEFAULT_SPEED, 3000, 100))
				{
					// �ص�ҩ����
					car_position = '0';
					//bsp_led_on(LED_GREEN);
					temp_step++;
					app_car_control_status = APP_CAR_CONTROL_STOP;
				}
			}
			else
			{
					if (car_go_until_sickroom(CAR_DEFAULT_SPEED, 6000, 100))
				{
					// �ص�ҩ����
					car_position = '0';
					//bsp_led_on(LED_GREEN);
					temp_step++;
					app_car_control_status = APP_CAR_CONTROL_STOP;
				}
			}
            
            break;
        default:
            break;
        }
}

void car_run_EFGH(uint16_t situation)//5678
{
	temp_step=0;
	switch (temp_step)
        {
        case 0:
			if(situation==5||situation==7)
			{
				if (car_spin(CAR_CONTROL_SPIN_LEFT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
			else
			{
				if (car_spin(CAR_CONTROL_SPIN_RIGHT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
            
            break;
        case 1:
            if (car_go_until_sickroom(CAR_DEFAULT_SPEED, 1500, 300))
            {
                // ���ﲡ����
				switch(situation)
				{
					case 5:car_position = 'e';break;
					case 6:car_position = 'f';break;
					case 7:car_position = 'g';break;
					case 8:car_position = 'h';break;
				}
                
                //bsp_led_on(LED_RED);
                temp_step++;
            }
            break;
        case 2:
            if (get_medicine_state() == (uint8_t)0)
            {
                //bsp_led_off(LED_RED);
                //buzzer_beep_tone(4000, 100, 100, 100);
                temp_step++;
            }
            break;
        case 3:
            if (car_spin(CAR_CONTROL_SPIN_RETURN_NUM, CAR_DEFAULT_SPEED, 500,
                         300))
            {
                temp_step++;
            }
            break;
        case 4:
            if (car_go_until_crossing(CAR_DEFAULT_SPEED, 500, 1200))
            {
				switch(situation)
				{
					case 5:car_position = '4';break;
					case 6:car_position = '4';break;
					case 7:car_position = '5';break;
					case 8:car_position = '5';break;
				}
                temp_step++;
            }
            break;
        case 5:
			if(situation==5||situation==7)
			{
				if (car_spin(CAR_CONTROL_SPIN_RIGHT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
			else
			{
				if (car_spin(CAR_CONTROL_SPIN_LEFT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
        
            break;
        case 6:
            if (car_go_until_crossing(CAR_DEFAULT_SPEED, 1500, 1200))
            {
                car_position = '3';
                temp_step++;
            }
            break;
        case 7:
			if(situation==5||situation==6)
			{
				if (car_spin(CAR_CONTROL_SPIN_RIGHT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
			else
			{
				if (car_spin(CAR_CONTROL_SPIN_LEFT_NUM, CAR_DEFAULT_SPEED, 250,
							 300))
				{
					temp_step++;
				}
			}
            
            break;
        case 8:
            if (car_go_until_sickroom(CAR_DEFAULT_SPEED, 10000, 100))
            {
                // �ص�ҩ����
                car_position = '0';
                //bsp_led_on(LED_GREEN);
                temp_step++;
                app_car_control_status = APP_CAR_CONTROL_STOP;
            }
            break;
		}
}

int car_control_k210_to_find_number(void)
{
	enum state_t
    {
        START = 0,
        WAIT_COMPLETE,
        STOP
    };
	static enum state_t state = START;
    static uint32_t temp_systick;
    static k210_data_t *_k210_data;
	
	_k210_data = get_k210_data();
	switch(state)
	{
		case START:
			send_uart_k210_to_find_number();
            temp_systick = get_system_tick();
			state++;
			break;
		
		case WAIT_COMPLETE:
			if (get_system_tick() - temp_systick >= 200)
			{
				if (_k210_data->work_mode == 0x01)
				{
					state++;
				}
				else
				{
					state--;
				}
			}
			state++;
			break;
		
		case STOP:
			state = START;
			return 1;
	}
	return 0;
}

int car_control_k210_to_find_lines(void)
{
    enum state_t
    {
        START = 0,
        WAIT_COMPLETE,
        STOP
    };
    static enum state_t state = START;
    static uint32_t temp_systick;
    static k210_data_t *_k210_data;

	_k210_data = get_k210_data();
	
    switch (state)
    {
    case START:
        send_uart_k210_to_find_lines();
        temp_systick = get_system_tick();
        state++;
        break;
    case WAIT_COMPLETE:
        if (get_system_tick() - temp_systick >= 200)
        {
            if (_k210_data->work_mode == 0x00)
            {
                state++;
            }
            else
            {
                state--;
            }
        }
        break;
    case STOP:
        state = START;
        return 1;
    }
    return 0;
}

int car_go_until_crossing_with_num_recognition(float _speed,
                                               int32_t _encoder_count,
                                               int32_t _position_target,
                                               char *left_medical_number,
                                               char *right_medical_number)
{
    enum _state_t
    {
        _START = 0,
        _WAIT_DECELERATE,
        _DECELERATE,
        _ENTER_NUM_RECOGNITION,
        _RECOGNITION_NUMBER,
        _EXIT_NUM_RECOGNITION,
        _POSITION_RUN,
        _STOP
    };
    static enum _state_t state = _START;

    static int32_t temp_start_distance = 0;
    static uint32_t temp_sys_tick = 0;
    static k210_data_t *_k210_data;

    _k210_data = get_k210_data();

    switch (state)
    {
    case _START:
        deactive_car_position_pid();
        active_car_red_lines_pid();

        set_car_red_lines_speed(_speed);
        temp_start_distance = motor1_state.now_position;///////
        state++;
        break;
    case _WAIT_DECELERATE:
        if (ABS(motor1_state.now_position - temp_start_distance) >= _encoder_count)
        {
            set_car_red_lines_speed(0.0f);
            state++;
        }
        break;
    case _DECELERATE:
        set_car_red_lines_speed(1.5f);
        if (_k210_data->recognition == 0x02)
        {
            state++;
            set_car_red_lines_speed(0.0f);
            active_car_position_pid();
            deactive_car_red_lines_pid();
        }
        break;
    case _ENTER_NUM_RECOGNITION:
        if (car_control_k210_to_find_number() == 1)
        {
            //servo1_pwm_pulse_set(SERVO_FIND_NUMBER);????????????????
            temp_sys_tick = get_system_tick();
            state++;
        }
        break;
    case _RECOGNITION_NUMBER:
        if (_k210_data->left_number != _k210_data->right_number)
        {
            *left_medical_number = _k210_data->left_number;
            *right_medical_number = _k210_data->right_number;
            state++;
        }else
        {
            if(get_system_tick() - temp_sys_tick >= 50)
            {
                temp_sys_tick = get_system_tick();
                //ǰ��
				tar(&motor1_state,10);//
				tar(&motor2_state,10);//
            }
        }
        break;
    case _EXIT_NUM_RECOGNITION:
        if (car_control_k210_to_find_lines() == 1)
        {
            //servo1_pwm_pulse_set(SERVO_FIND_LINE_ANGLE);??????????????????????
            state++;
             //ǰ��
			tar(&motor1_state,_position_target);//
			tar(&motor2_state,_position_target);//
        }
        break;
    case _POSITION_RUN:
        if (ABS(motor1_state.tar_position - motor1_state.now_position) <= 50)
        {
//            printf("m1_position_target,m1_position_measurement:%d,%d\n",
//                   (int32_t)get_m1_position_target(),
//                   get_m1_position_measurement());
            state++;
        }
        break;
    case _STOP:
        set_car_red_lines_speed(0.0f);
        deactive_car_position_pid();
        active_car_red_lines_pid();
        state = _START;
        return 1;
    }
    return 0;
}

void app_car_control_run(void)
{
	switch(app_car_control_status)
	{
		case APP_CAR_CONTROL_INIT:
			if (car_control_k210_to_find_number() == 1)
			{
				app_car_control_status++;
			}
			break;
			
		case APP_CAR_CONTROL_WAIT_FOR_K210_NUMBER:
			if (get_start_number() != 0)
			{
				medical_ward_info.need_to_medical_ward_number = get_start_number();
			}
			if (0 != medical_ward_info.need_to_medical_ward_number)
			{
				if (car_control_k210_to_find_lines() == 1)
				{
					//buzzer_beep_tone(4000, 100, 100, 100);
					app_car_control_status++;
				}
			}
        break;
			
		case APP_CAR_CONTROL_WAIT_FOR_LOAD:
        if (1)//(get_medicine_state() == (uint8_t)1)//��Ҫһ���ܵõ�ҩƷ״̬�ĺ���
        {
            //buzzer_beep_tone(4000, 100, 100, 100);
            app_car_control_status++;
        }
        break;

		case APP_CAR_CONTROL_FIRST_JUDGE:
        if (get_start_number() == 1)
        {
            app_car_control_status = APP_CAR_CONTROL_GOTO_A;
        }
        else if (get_start_number() == 2)
        {
            app_car_control_status = APP_CAR_CONTROL_GOTO_B;
        }
        else // ���ǽ��˲���
        {
            app_car_control_status = APP_CAR_CONTROL_SECOND_JUDGE;
        }
        break;
		
		case APP_CAR_CONTROL_GOTO_A:
			step_situation=1;
			car_run_ABCD(step_situation);
		break;
		
		case APP_CAR_CONTROL_GOTO_B:
			step_situation=2;
			car_run_ABCD(step_situation);
		break;
		
		case APP_CAR_CONTROL_SECOND_JUDGE:
        if (car_go_until_crossing_with_num_recognition(
                CAR_DEFAULT_SPEED, 7000, 1100,
                &medical_ward_info.medical_ward_c,
                &medical_ward_info.medical_ward_d)
            == 1)
        {
            car_position = '2';
            if (medical_ward_info.medical_ward_c
                == medical_ward_info.need_to_medical_ward_number)
            {
                //printf("to left ward\n");
                app_car_control_status = APP_CAR_CONTROL_2_GOTO_C;
            }
            else if (medical_ward_info.medical_ward_d
                     == medical_ward_info.need_to_medical_ward_number)
            {
                //printf("to right ward\n");
                app_car_control_status = APP_CAR_CONTROL_2_GOTO_D;
            }
            else
            {
                app_car_control_status = APP_CAR_CONTROL_THIRD_JUDGE;
            }
        }

        break;
		
		case APP_CAR_CONTROL_2_GOTO_C:
			step_situation=3;
			car_run_ABCD(step_situation);
		break;
		
		case APP_CAR_CONTROL_2_GOTO_D:
			step_situation=4;
			car_run_ABCD(step_situation);
		break;
		
		case APP_CAR_CONTROL_THIRD_JUDGE:

        switch (third_temp_step)
        {
        case 0:
            if (car_go_until_crossing(CAR_DEFAULT_SPEED, 3000, 1300))
            {
                car_position = '3';
                third_temp_step++;
            }
            break;
        case 1:
            if (car_spin(CAR_CONTROL_SPIN_LEFT_NUM, CAR_DEFAULT_SPEED, 250,
                         300))
            {
                third_temp_step++;
            }
            break;
        case 2:
            if (car_go_until_crossing_with_num_recognition(
                    CAR_DEFAULT_SPEED, 3000, 1300,
                    &medical_ward_info.medical_ward_e,
                    &medical_ward_info.medical_ward_f)
                == 1)
            {
                car_position = '4';
                if (medical_ward_info.medical_ward_e
                    == medical_ward_info.need_to_medical_ward_number)
                {
                    //printf("to left ward\n");
                    app_car_control_status = APP_CAR_CONTROL_4_GOTO_E;
                }
                else if (medical_ward_info.medical_ward_f
                         == medical_ward_info.need_to_medical_ward_number)
                {
                    //printf("to right ward\n");
                    app_car_control_status = APP_CAR_CONTROL_4_GOTO_F;
                }
                else
                {
                    app_car_control_status = APP_CAR_CONTROL_FOURTH_JUDGE;
                }
            }
            break;
        }
        break;
		
		case APP_CAR_CONTROL_4_GOTO_E:
			step_situation=5;
			car_run_EFGH(step_situation);
			
		break;
		
		case APP_CAR_CONTROL_4_GOTO_F:
			step_situation=6;
			car_run_EFGH(step_situation);
			
		break;
		
		case APP_CAR_CONTROL_FOURTH_JUDGE:

			switch (fourth_temp_step)
			{
			case 0:
				if (car_spin(CAR_CONTROL_SPIN_RETURN_NUM, CAR_DEFAULT_SPEED, 500,
							 300))
				{
					fourth_temp_step++;
				}
				break;
			case 1:
				if (car_go_until_crossing_with_num_recognition(
						CAR_DEFAULT_SPEED, 5000, 1300,
						&medical_ward_info.medical_ward_g,
						&medical_ward_info.medical_ward_h)
					== 1)
				{
					car_position = '5';
					if (medical_ward_info.medical_ward_g
						== medical_ward_info.need_to_medical_ward_number)
					{
						//printf("to left ward\n");
						app_car_control_status = APP_CAR_CONTROL_5_GOTO_G;
					}
					else if (medical_ward_info.medical_ward_h
							 == medical_ward_info.need_to_medical_ward_number)
					{
						//printf("to right ward\n");
						app_car_control_status = APP_CAR_CONTROL_5_GOTO_H;
					}
					else
					{
						// no pharmacy to go
						app_car_control_status = APP_CAR_CONTROL_5_GOTO_G;
					}
				}
				break;
			}
			break;
		case APP_CAR_CONTROL_5_GOTO_G:
			step_situation=7;
			car_run_EFGH(step_situation);
		break;
		
		case APP_CAR_CONTROL_5_GOTO_H:
			step_situation=8;
			car_run_EFGH(step_situation);
		break;
		
		case APP_CAR_CONTROL_STOP:
			
		break;
	
	}
}
