#include "stm32f10x.h"                  // Device header
#include "Motor.h"                  // Device header
void Go_Ahead(float left_speed, float right_speed)
{
    Motor_SetLeftSpeed(left_speed);
    Motor_SetRightSpeed(right_speed);
}

void Go_Back(float left_speed, float right_speed)
{
    Motor_SetLeftSpeed(-left_speed);
    Motor_SetRightSpeed(-right_speed);
}

void Turn_Left(float left_speed, float right_speed)
{
    Motor_SetLeftSpeed(0);
    Motor_SetRightSpeed(right_speed);
}

void Turn_Right(float left_speed, float right_speed)
{
    Motor_SetLeftSpeed(left_speed);
    Motor_SetRightSpeed(0);
}

void Self_Left(float left_speed, float right_speed)
{
    Motor_SetLeftSpeed(left_speed);
    Motor_SetRightSpeed(-right_speed);
}

void Self_Right(float left_speed, float right_speed)
{
    Motor_SetLeftSpeed(-left_speed);
    Motor_SetRightSpeed(right_speed);
}

void Car_Stop(float left_speed, float right_speed)
{
    Motor_SetLeftSpeed(0);
    Motor_SetRightSpeed(0);
}

