#ifndef __medicine_run_H
#define __medicine_run_H

#include "stm32f10x.h"                  // Device header

int get_medicine_state(void);

#endif
