#include "stm32f10x.h"
#include "motorcan.h"
#include "motor.h"
#include "pid.h"
#include "ENCODER.H"

typedef enum
{
    APP_PID_INIT = 0,
    APP_PID_RUN,
	APP_PID_STOP,
} app_pid_status_t;

static app_pid_status_t app_pid_status = APP_PID_INIT;

// С�����λ�û�������־λ״̬
__attribute__((used)) static char car_position_pid_enable_flag = 1;
// С��Ѳ���߻�������־λ״̬
__attribute__((used)) static char car_find_red_line_enable_flag = 1;



//�ٶȻ���ر���
static pid_t motor1_speed_pid;
static pid_t motor2_speed_pid;

extern float motor1_speed_target ;
extern float motor2_speed_target ;

//λ�û���ر���
static pid_t motor1_position_pid;
static pid_t motor2_position_pid;

extern int64_t motor1_position_target ;
extern int64_t motor2_position_target ;

extern MOTOR1_CAN motor1_state;
extern MOTOR2_CAN motor2_state;

// λ�û��ó������ٶȣ����ֵ���Ҫ������ٶȻ�
static float position_result_motor1_speed_target = 0.0f;
static float position_result_motor2_speed_target = 0.0f;


// Ѳ�߻��ó������ٶȣ����ֵ���Ҫ������ٶȻ�
float red_lines_result_motor1_speed_target = 0.0f;


// PID ����֮����ٶ�(����С���Զ��ٵ��ٶ�ǰ��)
float raw_target_speed = 0.0f;


float motor_pid[6] = {1,0,0,2,0,0};
float motor_limit[2]={50,50};

void app_pid_run(void)
{

    static int16_t motor1_pwm_value = 0;
    static int16_t motor2_pwm_value = 0;

 //   static int32_t position1_measurement;
 //   static int32_t position2_measurement;
    switch (app_pid_status)
    {
    case APP_PID_INIT:
      // �ٶȻ�����
        //  motor1 �ٶȻ� pid ������ʼ��
       PID_struct_init(&motor1_speed_pid, 1, motor_limit[0], motor_limit[0],motor_pid[0] ,motor_pid[1],motor_pid[2]);//3.5, 1.2,0
        // �޸�motor1 �ٶȻ� kp ki kd
       // motor1_speed_pid.f_pid_reset(&motor1_speed_pid, 6, 5,
        //                                          0);

        // motor2 �ٶȻ� pid ������ʼ��
        PID_struct_init(&motor2_speed_pid, 1, motor_limit[0], motor_limit[0], motor_pid[0],motor_pid[1],motor_pid[2]);
        // �޸�motor2 �ٶȻ� kp ki kd
       // motor2_speed_pid.f_pid_reset(&motor2_speed_pid, 6, 5,
         //                                         0);

        //λ�û�����
        // λ�û�����
        //  motor1 λ�û� pid ������ʼ��
        PID_struct_init(&motor1_position_pid, 1, motor_limit[1],motor_limit[1],motor_pid[3],motor_pid[4], motor_pid[5]);//1, 0, 0.5
        // �޸� motor1 λ�û� kp ki kd
      //  motor1_position_pid.f_pid_reset(&motor1_position_pid, 0.0065f, 0,
       //                                              0);
        // motor2 λ�û� pid ������ʼ��
      PID_struct_init(&motor2_position_pid, 1, motor_limit[1],motor_limit[1],motor_pid[3],motor_pid[4], motor_pid[5]);
        // �޸� motor2 λ�û� kp ki kd
        //motor2_position_pid.f_pid_reset(&motor2_position_pid, 0.0065f, 0,
        //                                             0);

//        _k210_data = get_k210_data();
//      // Ѳ���߻���pid����
        //  Ѱ���� pid ������ʼ��
//        positional_pid_init(&red_lines_pid, 0.004f, 0, 0, 5, 1.5, -1.5);
        // �޸� Ѱ���� kp ki kd
 //       red_lines_pid.positional_pid_set_value(&red_lines_pid, 0.008f, 0, 0.8f,
//                                               5.0f, 5, -5);
//                                   5.0f, 5, -5);

        app_pid_status++;
        break;
    case APP_PID_RUN:
		
		// ������1��PWM���ֵ
		motor1_pwm_value = (int16_t)pid_calc(
			&motor1_speed_pid,motor1_state.now_speed , motor1_speed_target);
		// Ӧ�õ��1��PWMֵ
		Motor_SetLeftSpeed(motor1_pwm_value);

		// ������2��pwm���ֵ
		motor2_pwm_value = (int16_t)pid_calc(
			&motor2_speed_pid, motor2_state.now_speed, motor2_speed_target);
		// Ӧ�õ��2��PWMֵ
		Motor_SetRightSpeed(motor2_pwm_value);


		//	position1_measurement = motor1_state.now_position;
		//	position2_measurement = motor2_state.now_position;
		if (car_position_pid_enable_flag == 1)//����
		{
			position_result_motor1_speed_target = (pid_calc(
				&motor1_position_pid,(float)motor1_state.now_position ,
					(float)motor1_position_target));
			position_result_motor2_speed_target = (pid_calc(
				&motor2_position_pid,(float)motor2_state.now_position ,
					(float)motor2_position_target));
				if(position_result_motor1_speed_target==0&&motor1_state.now_position>0.1)
				{
					app_pid_status++;
				}
		}
		else
		{
			motor1_position_target = motor1_state.now_position;
			motor2_position_target = motor2_state.now_position;
			position_result_motor1_speed_target = 0;
			position_result_motor2_speed_target = 0;
		}
		
		
/*		lines_offset = _k210_data->center_block_offset;

        if (abs(_k210_data->top_block_offset)
                >= abs(_k210_data->center_block_offset)
            && (abs(_k210_data->top_block_offset) <= 80))
        {
            lines_offset = _k210_data->top_block_offset;
        }
        // ���ǰ������û�ˣ�����0�������л��������ĵ�ƫ��
        if (abs(_k210_data->top_block_offset) <= 1)
        {
            lines_offset = _k210_data->center_block_offset;
        }
        if (abs(lines_offset) > 200)
        {
            lines_offset = 0;
        }
        // Ѳ���߻�
        if (car_find_red_line_enable_flag == 1)
        {
            red_lines_result_motor1_speed_target = positional_pid_compute(
                &red_lines_pid, 0, lines_offset);
        }
        else
        {
            red_lines_result_motor1_speed_target = 0;
        }*/
		
		 motor1_speed_target = raw_target_speed
                              + red_lines_result_motor1_speed_target
                              + position_result_motor1_speed_target;
        motor2_speed_target = raw_target_speed
                              + (-red_lines_result_motor1_speed_target)
                              + position_result_motor2_speed_target;
//							  if(myabs(position_result_motor1_speed_target-motor1_state.now_position)<5)
//							  {
//								  app_pid_status++;
//							  }
		break;
	case APP_PID_STOP:
		Motor_SetLeftSpeed(0);
	Motor_SetRightSpeed(0);
		break;
	}
}

