#ifndef _pid_run_H
#define _pid_run_H
#include "stm32f10x.h"                  // Device header
#include "motorcan.h"
void app_pid_run(void);

extern void GET_MOTOR1_CAN(MOTOR1_CAN *ptr,int16_t tarspeed,int16_t tarposition);
extern void GET_MOTOR2_CAN(MOTOR2_CAN *ptr,int16_t tarspeed,int16_t tarposition);
#endif


