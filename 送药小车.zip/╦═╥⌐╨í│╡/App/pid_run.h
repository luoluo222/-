#ifndef _pid_run_H
#define _pid_run_H
#include "stm32f10x.h"                  // Device header
#include "motorcan.h"

void app_pid_run(void);
void active_car_position_pid(void);
void deactive_car_position_pid(void);
void active_car_red_lines_pid(void);
void deactive_car_red_lines_pid(void);
void set_car_red_lines_speed(float _speed);
void tar(MOTOR_CAN* ptr, int tarposition1);

#endif


