#ifndef _pid_run_H
#define _pid_run_H
#include "stm32f10x.h"                  // Device header
#include "motorcan.h"
void app_pid_run(void);

#endif


