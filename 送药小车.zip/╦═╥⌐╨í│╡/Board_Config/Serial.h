#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>
#include <stdarg.h>
#include "stm32f10x.h"                  // Device header

#define RxBufferSize   (countof(RxBuffer) - 1)

#define countof(a)   (sizeof(a) / sizeof(*(a)))

void My_UART_Init(void);
extern uint8_t Rx_Flag;


#endif
