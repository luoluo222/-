/*

�������
������1�õ�TIM3��CH1��CH2,��PA6��PA7
�����PWM�õ�TIM2,PA0��PA1�����·ͨ��

*/
#include "stm32f10x.h"        
#include "LED.H"
#include "DELAY.H"
#include "PWM.H"
#include "MOTOR.H"
#include "ENCODER.H"
#include "PID.H"
#include "OLED.H"
#include "Serial.h"
#include "Motor.h" 
#include "key.h"
#include <STM32_to_K210.h>
#include "lanya.h"
#include "upacker.h" 
#include "STM32_to_K210.h" 
#include "pid_run.h"
#include "Timer.h"
#include "Sys_Time_IRQHandle.h"
#include "car_run.h"

MOTOR_CAN motor1_state;
MOTOR_CAN motor2_state;

extern int16_t tar_psoition , tar_speed ;
extern int16_t tar_psoition1 , tar_speed1 ;

void tar(MOTOR_CAN* ptr, int position);	

int32_t pos[2];
uint8_t flag = 1;

k210_data_t* K210_data;



int main(void)
{
	Timer_Init();
	Motor_Init();
    Encoder_Init();
	Encoder2_Init();
    OLED_Init();
    My_UART_Init();
	Key_Init();
	tar(&motor1_state,2000);
	tar(&motor2_state,-2000);
	
	K210_data = get_k210_data();
    while(1)
    {
		if(Encoder_start)
		{
			Encoder_start = 0;
			(++motor1_state.motor_cnt)<=20?Motor_ecd_init(&motor1_state):GET_MOTOR_CAN(&motor1_state,motor1_state.tar_speed);
			(++motor2_state.motor_cnt)<=20?Motor_ecd_init(&motor2_state):GET_MOTOR_CAN(&motor2_state,motor2_state.tar_speed);
		}
		
		if(PID_start)
		{
			PID_start = 0;
			app_pid_run();
		}
		if(Car_run_start)//300ms
		{
			Car_run_start=0;
			app_car_control_run();
		}
		app_protocol_run();
     }
  }

//void tar(MOTOR_CAN* ptr, int tarposition1)//, int tarspeed1)
//{
//    // ʹ���»��ߺͲ�����������һ����#define tar_psoition    
//    ptr->tar_position = tarposition1;
//}


void USART3_IRQHandler(void)
{
	if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
	{
		USART_ReceiveData(USART3);
		
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);
	}
}

