/*

�������
������1�õ�TIM3��CH1��CH2,��PA6��PA7
�����PWM�õ�TIM2,PA0��PA1�����·ͨ��

*/
#include "stm32f10x.h"        
#include "LED.H"
#include "DELAY.H"
#include "PWM.H"
#include "MOTOR.H"
#include "ENCODER.H"
#include "PID.H"
#include "OLED.H"
#include "Serial.h"
#include "Motor.h" 
#include "key.h"
#include <STM32_to_K210.h>
#include "lanya.h"
#include "upacker.h" 
#include "STM32_to_K210.h" 
#include "pid_run.h"
#include "Timer.h"
#include "Sys_Time_IRQHandle.h"


float motor1_speed_target ;//Ŀ���ٶ�
float motor2_speed_target ;

int64_t motor1_position_target ;//Ŀ��λ��
int64_t motor2_position_target ;

MOTOR1_CAN motor1_state;
MOTOR2_CAN motor2_state;

extern int16_t tar_psoition , tar_speed ;
extern int16_t tar_psoition1 , tar_speed1 ;

void tar(int position);	
void tar1(int tarposition1);


int main(void)
{
	Timer_Init();
	Motor_Init();
    Encoder_Init();
	Encoder2_Init();
    OLED_Init();
    My_UART_Init();
	Key_Init();
	tar1(20000);
	tar(20000);
    while(1)
    {
		if(Encoder_start)
		{
			Encoder_start = 0;
			
			GET_MOTOR2_CAN(&motor2_state,motor2_speed_target,motor2_position_target);GET_MOTOR1_CAN(&motor1_state,motor1_speed_target,motor1_position_target);
		}
		
		if(PID_start)
		{
			PID_start = 0;
			app_pid_run();
		}
		
		
		
     }
  }

void tar1(int tarposition1)//, int tarspeed1)
{
    // ʹ���»��ߺͲ�����������һ����#define tar_psoition    

    motor1_position_target = tarposition1;
   // motor1_speed_target = tarspeed1;
}
void tar(int tarposition)//, int tarspeed) 
{
    // ʹ���»��ߺͲ�����������һ����#define tar_psoition    
    motor2_position_target = tarposition;
  //  motor2_speed_target = tarspeed;
}


void USART3_IRQHandler(void)
{
	if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
	{
		USART_ReceiveData(USART3);
		
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);
	}
}

