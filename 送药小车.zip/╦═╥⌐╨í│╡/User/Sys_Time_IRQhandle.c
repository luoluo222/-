#include "Sys_Time_IRQHandle.h"

uint32_t Sys_Time;
uint8_t PID_Run_Tick = 200;
uint32_t Encoder_Tick = 200;
uint16_t Car_run_Tick = 300;


uint8_t PID_start;
uint8_t Encoder_start;
uint8_t Car_run_start;


void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		Sys_Time += 1;
		
		if(0xffffffff - Sys_Time <= 10) Sys_Time = 0;
		if(Sys_Time % PID_Run_Tick == 0)	PID_start = 1;
		if(Sys_Time % Encoder_Tick == 0)	Encoder_start = 1;
		if(Sys_Time % Car_run_Tick == 0)	Car_run_start = 1;
		
		
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}

uint32_t get_system_tick(void)
{
	return Sys_Time;
}
