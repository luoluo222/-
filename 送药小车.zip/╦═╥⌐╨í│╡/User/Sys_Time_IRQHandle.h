#ifndef _SYSTIME_IRQHANDLE_H
#define _SYSTIME_IRQHANDLE_H

#include "stm32f10x.h"                  // Device header

extern uint8_t PID_start;
extern uint8_t Encoder_start;
extern uint8_t Car_run_start;

uint32_t get_system_tick(void);

#endif
