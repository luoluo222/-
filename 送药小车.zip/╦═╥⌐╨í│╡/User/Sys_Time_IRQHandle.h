#ifndef _SYSTIME_IRQHANDLE_H
#define _SYSTIME_IRQHANDLE_H

#include "stm32f10x.h"                  // Device header

extern uint8_t PID_start;
extern uint8_t Encoder_start;


#endif
